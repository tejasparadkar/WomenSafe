package com.example.BSafe;

@androidx.databinding.BindingBuildInfo
public class DataBindingTriggerClass {}